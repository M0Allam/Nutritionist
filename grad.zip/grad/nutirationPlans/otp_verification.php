<?php
require('conn.php');
ob_start();

if (isset($_GET['username'])) {
    $uname = htmlspecialchars($_GET['username']);
} else {
    echo "Username not provided.";
    exit;
}

$wrongData = [];

if (isset($_POST['verify'])) {
    $otp = htmlspecialchars($_POST['otp']);

    // Fetch user data by username
    $selectQuery = "SELECT * FROM `users` WHERE `username` = '$uname'";
    $selectDone = mysqli_query($conn, $selectQuery);
    $data = mysqli_fetch_assoc($selectDone);

    if ($data) {
        // Verify OTP
        if ($otp == $data['otp']) {
            // OTP matched, login successful
            // Clear OTP from database
            $clearOTPQuery = "UPDATE `users` SET `otp` = NULL WHERE `username` = '$uname'";
            mysqli_query($conn, $clearOTPQuery);

            session_start();
            $_SESSION['login'] = $uname;
            $_SESSION['user_id'] = $data['id']; // Save user ID in session
            header("location: index.php");
            exit;
        } else {
            $wrongData['wrongotp'] = "Invalid OTP";
        }
    } else {
        $wrongData['notfound'] = "User Not Found";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
    <!-- Include CSS files -->
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body class="d-flex align-items-center justify-content-center bg-dark">
    <div class="login-page m-auto">
        <div class="form">
            <form method="post">
                <h1>OTP Verification</h1>
                <input type="text" placeholder="Enter OTP" name="otp">
                <p>
                    <?php
                    if (isset($wrongData['wrongotp'])) {
                        echo ($wrongData['wrongotp']);
                    }
                    ?>
                </p>
                <input type="submit" value="Verify" name="verify">
            </form>
        </div>
    </div>

    <!-- Include JavaScript files -->
    <script src="js/main.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
ob_end_flush();
?>
