<?php
session_start();

// Logout functionality
if (isset($_POST['logout'])) {
    session_destroy();
}

// Check if the user is logged in
if (isset($_SESSION['login'])) {
    $redirectUrl = 'plans.php'; // Redirect to plans.php if the user is logged in
} else {
    $redirectUrl = 'signup.php'; // Redirect to signup.php if the user is not logged in
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="css\bootstrap.min.css">
    <link rel="Icon" href="imgs/logo2.png">
    <title>Nutritionist</title>

    <style>
    .HeroSection {
        background: linear-gradient(to right, #396c5a, #c9e483);
        position: relative;
        height: 100vh;
    }

    .d-none {
        display: none;
    }

    #downloadButton {
        display: none;
    }

    #downloadButtonDes {
        display: none;
    }

    /* Table Styling */
    .workout-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .workout-table th,
    .workout-table td {
        border: 1px solid #dddddd;
        text-align: center;
        padding: 8px;
    }

    .workout-table th {
        background-color: #f2f2f2;
    }

    /* Additional Styling */
    .workout-div {
        margin-top: 20px;
    }

    .workout-div li {
        margin-bottom: 10px;
    }

    .workout-div a {
        text-decoration: none;
        color: #007bff;
    }

    .workout-div a:hover {
        text-decoration: underline;
    }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg ">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"><img src="imgs\logo.png" alt=""></a>
            <button class="hamburger" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">

                <div class="line1"></div>
                <div class="line2"></div>
                <div class="line3"></div>

            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#Features">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#Blogs">Blogs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $redirectUrl; ?>">Plans</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="books.php">Books</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="doctors.html">Doctors</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="team.html">About Team</a>
                    </li>
                    <?php if (isset($_SESSION["login"])) {
                        if ($_SESSION['login'] != "admin") { ?>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <?php echo ($_SESSION['login']); ?>
                        </a>
                    </li>
                    <?php } else { ?>
                    <li><a href="users.php">View Users</a></li>
                    <li><a href="editProducts.php">Edit Products</a></li>
                    <?php }
                    ?>
                    </li>
                    <li class="nav-item">
                        <form method="post" action="logout.php">
                            <input type="hidden" name="redirect" value="index.php">
                            <input class="login nav-link" type="submit" value="Logout" name="logout">
                        </form>
                    </li>
                    <?php } else { ?>
                    <li><a class="login nav-link" href="login.php">Login</a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </nav>


    <!-- Header section -->
    <section class="HeroSection">
        <div class="container d-flex flex-column">
            <div class="row row-cols-1 row-cols-md-2">
                <link rel="Icon" href="imgs/logo2.png">
                <img class="Image m-0" src="imgs/Header.png">
                <div class="m-auto">
                    <div class="SubContainer">
                        <div class="Container2">
                            <div class="SubContainer2">
                                <div class="Container3">
                                    <div class="Heading d-flex align-items-center my-2">
                                        <h1 class="pb-3">
                                            Transform Your ❤️ Health with
                                        </h1>
                                    </div>
                                </div>
                                <div class="Heading2">
                                    <h1>
                                        Personalized Nutrition Coaching
                                    </h1>
                                </div>
                            </div>
                            <div class="Paragraph pb-3">
                                Welcome to Nutritionist, your partner in achieving optimal health through personalized
                                nutrition coaching. Our certified nutritionists are here to guide you on your weight
                                loss
                                journey, providing customized plans and ongoing support. Start your transformation today
                                and
                                experience the power of personalized nutrition coaching.
                            </div>
                        </div>
                        <div class="ButtonsContainer d-flex gap-3 mb-3">
                            <div class="Button">
                                <a href="<?php echo $redirectUrl; ?>" class="btn btn-primary"
                                    style="background-color: #CBEA7B; color: black; font-size: 1.1rem; transition: all 0.3s ease-in-out;">
                                    Get Started Today
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="SubContainer3 d-flex align-items-center">
                        <div class="Container4">
                            <img class="image" src="imgs/Container.png" />
                        </div>
                        <div class="Text3 mx-2 fw-bold fs-5">
                            <span>430+</span>
                            <span class="span">Happy Customers</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <style>
    .Button a:hover {
        transform: scale(1.05);
        /* Increase the size by 5% on hover */
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        /* Add a shadow effect on hover */
    }
    </style>




    <!-- Features section -->


    <section id="Features" class="container d-flex flex-column gap-5">
        <h1 class="mt-3 text-center display-4">Features</h1>
        <p class="text-center lead">Welcome to the Feature Section of Nutritionist, your ultimate destination for all
            things
            nutrition and wellness.</p>

        <div class="row row-cols-1 row-cols-md-3 justify-content-center  gx-4">
            <div class="Features col d-flex flex-column rounded-lg bg-light">
                <a href="plans.php" class="text-decoration-none text-dark">
                    <div class="d-flex justify-content-start align-items-center px-4 py-3  rounded-top bg-light ">
                        <img src="imgs\Features Icon.png" alt="">
                        <h5 class="ms-3 mb-0">Personalized Nutrition Plans</h5>
                    </div>
                    <p class="px-4 text-muted">Receive a tailored nutrition plan designed specifically for your body and
                        goals. Our certified nutritionists will consider your unique needs, dietary preferences, and
                        health
                        conditions to create a plan that suits you best.</p>
                </a>
            </div>

            <div class="Features col d-flex flex-column gap-4 rounded-lg bg-light">
                <a href="books.php" class="text-decoration-none text-dark">
                    <div class="d-flex justify-content-start align-items-center px-4 py-3  rounded-top bg-light">
                        <img src="imgs\Features Icon (1).png" alt="">
                        <h5 class="ms-3 mb-0">Get a muscled knowledge</h5>
                    </div>
                    <p class="px-4 text-muted">Discover a curated selection of guides and manuals designed to enhance
                        your health and fitness journey. Explore personalized nutrition plans, effective workout
                        routines, and lifestyle coaching resources. Start your transformation today!.</p>
                </a>
            </div>

            <div class="Features col d-flex flex-column gap-4  rounded-lg  bg-light">
                <a href="workouts.php" class="text-decoration-none text-dark">
                    <div class="d-flex justify-content-start align-items-center px-4 py-3  rounded-top bg-light">
                        <img src="imgs\Features Icon (4).png" alt="">
                        <h5 class="ms-3 mb-0">Lifestyle and Behavior Coaching</h5>
                    </div>
                    <p class="px-4 text-muted">Achieving sustainable results requires more than just a diet plan. Our
                        nutritionists
                        will work with you to develop healthy habits, address emotional eating, and provide strategies
                        to overcome
                        obstacles along the way.</p>
                </a>
            </div>

        </div>
    </section>



    <!-- our blogs section -->


    <section id="Blogs" class="container d-flex flex-column justify-content-center align-items-start gap-5">
        <div class="row d-flex flex-column justify-content-center align-items-center gap-3">
            <div class="col text-center">
                <h1 class="display-4">Our Blogs</h1>
                <p class="lead">Our blog is a treasure trove of informative and engaging articles written by our team of
                    nutritionists, dietitians, and wellness experts. Here's what you can expect from our blog.</p>
            </div>
        </div>
        <div class="row d-flex justify-content-center gap-4">
            <!-- Weight Loss Blog Card -->
            <a href="Blog.php" class="col-md-5 mb-3 text-decoration-none">
                <div class="card rounded h-100">
                    <img src="./imgs/our blog(1).png" class="blog card-img-top rounded-top" alt="Blog Post Image 1">
                    <div class="blogs card-body d-flex flex-column justify-content-between">
                        <div class="d-flex flex-column gap-2">
                            <h5 class="card-title">Weight Loss</h5>
                            <p class="card-text">Discover how staying hydrated can support your weight loss goals and
                                improve overall
                                health.</p>
                        </div>
                        <div class="d-flex flex-row justify-content-between align-items-center">
                            <div class="d-flex align-items-center gap-2">
                                <img src="imgs/Image (8).png" class="rounded-circle" alt="Author Avatar">
                                <div class="text-start">
                                    <p class="mb-0 mt-3">Emily Johnson</p>
                                    <small class="text-muted">23 May 2023 - 5 min read</small>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <img src="imgs/Icon Container (6).png" alt="Icon">
                                <img src="imgs/Icon Container (7).png" alt="Icon">
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            <!-- Mindful Eating Blog Card -->
            <a href="Blog.php" class="col-md-5 mb-3 text-decoration-none">
                <div class="card shadow rounded h-100">
                    <img src="imgs/our blog (2).png" class="blog card-img-top rounded-top" alt="Blog Post Image 2">
                    <div class="blogs card-body d-flex flex-column justify-content-between">
                        <div class="d-flex flex-column gap-2">
                            <h5 class="card-title">Mindful Eating</h5>
                            <p class="card-text">Cultivating a Healthy Relationship with Food</p>
                        </div>
                        <div class="d-flex flex-row justify-content-between align-items-center">
                            <div class="d-flex align-items-center gap-2">
                                <img src="imgs/Image (9).png" class="rounded-circle" alt="Author Avatar">
                                <div class="text-start">
                                    <p class="mb-0">Sarah Thompson</p>
                                    <small class="text-muted">23 May 2023 - 5 min read</small>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <img src="imgs/Icon Container (6).png" alt="Icon">
                                <img src="imgs/Icon Container (7).png" alt="Icon">
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            <!-- Understanding Macronutrients Blog Card -->
            <a href="Blog.php" class="col-md-5 mb-3 text-decoration-none">
                <div class="card shadow rounded h-100">
                    <img src="imgs/our blog (3).png" class="blog card-img-top rounded-top" alt="Blog Post Image 3">
                    <div class="blogs card-body d-flex flex-column justify-content-between">
                        <div class="d-flex flex-column gap-2">
                            <h5 class="card-title">Understanding Macronutrients</h5>
                            <p class="card-text">Carbohydrates, Proteins, and Fats</p>
                        </div>
                        <div class="d-flex flex-row justify-content-between align-items-center">
                            <div class="d-flex align-items-center gap-2">
                                <img src="imgs/Image (10).png" class="rounded-circle" alt="Author Avatar">
                                <div class="text-start">
                                    <p class="mb-0">Mark Wilson</p>
                                    <small class="text-muted">23 May 2023 - 5 min read</small>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <img src="imgs/Icon Container (6).png" alt="Icon">
                                <img src="imgs/Icon Container (7).png" alt="Icon">
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            <!-- Healthy Snacks on the Go Blog Card -->
            <a href="Blog.php" class="col-md-5 mb-3 text-decoration-none">
                <div class="card shadow rounded h-100">
                    <img src="imgs/our blog (4).png" class="blog card-img-top rounded-top" alt="Blog Post Image 4">
                    <div class="blogs card-body d-flex flex-column justify-content-between">
                        <div class="d-flex flex-column gap-2">
                            <h5 class="card-title">Healthy Snacks on the Go</h5>
                            <p class="card-text">Quick and Nutritious Options</p>
                        </div>
                        <div class="d-flex flex-row justify-content-between align-items-center">
                            <div class="d-flex align-items-center gap-2">
                                <img src="imgs/Image (11).png" class="rounded-circle" alt="Author Avatar">
                                <div class="text-start">
                                    <p class="mb-0 mt-3">Emily Johnson</p>
                                    <small class="text-muted">23 May 2023 - 5 min read</small>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <img src="imgs/Icon Container (6).png" alt="Icon">
                                <img src="imgs/Icon Container (7).png" alt="Icon">
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </section>

    <footer class="footer py-3">
        <p class="copyright fw-bold display-8  text-white text-center">&copy; 2024 Nutritionist. All rights reserved.
        </p>
    </footer>


    <script src="js/main.js"></script>
    <script src="js\bootstrap.bundle.min.js"></script>




</body>

</html>