<?php
session_start();

require('conn.php');
ob_start();

$registrationSuccess = false;
$registrationError = '';

if (isset($_POST['register'])) {
    // Retrieve form data
    $ufullname = htmlspecialchars($_POST['ufullname']);
    $uname = htmlspecialchars($_POST['uname']);
    $pw = htmlspecialchars($_POST['pw']);
    $uemail = htmlspecialchars($_POST['uemail']);

    // Implementing a basic password policy
    $passwordMinLength = 8;
    $passwordMaxLength = 20;
    $passwordPattern = '/^(?=.*\d)(?=.*[A-Za-z])(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,20}$/';

    if (strlen($pw) < $passwordMinLength || strlen($pw) > $passwordMaxLength) {
        $registrationError = "Password must be between $passwordMinLength and $passwordMaxLength characters long.";
    } elseif (!preg_match($passwordPattern, $pw)) {
        $registrationError = "Password must contain at least one digit, one uppercase letter, one lowercase letter, and one special character.";
    } else {
        // Hash the password before storing it in the database
        $hashedPassword = password_hash($pw, PASSWORD_DEFAULT);

        // Image upload handling if a file is provided
        $imageDirectory = 'uploads/';
        $imageDestination = '';

        if (!empty($_FILES['uimg']['name'])) {
            $imageName = $_FILES['uimg']['name'];
            $imageTmpName = $_FILES['uimg']['tmp_name'];
            $imageSize = $_FILES['uimg']['size'];
            $imageError = $_FILES['uimg']['error'];

            // Validate file size and type before moving the file
            if ($imageError === 0) {
                $imageDestination = $imageDirectory . $imageName;
                if ($imageSize <= 5000000) { // Maximum file size: 5 MB
                    $allowedExtensions = ['jpg', 'jpeg', 'png', 'php'];
                    $fileExtension = strtolower(pathinfo($imageName, PATHINFO_EXTENSION));
                    if (in_array($fileExtension, $allowedExtensions)) {
                        move_uploaded_file($imageTmpName, $imageDestination);
                    } else {
                        $registrationError = "Only JPG, JPEG, and PNG files are allowed.";
                    }
                } else {
                    $registrationError = "File size exceeds the limit (5 MB).";
                }
            } else {
                $registrationError = "There was an error uploading your image.";
            }
        }

        if (empty($registrationError)) {
            // Insert user data into the database
            $insertQuery = "INSERT INTO `users` (`ufullname`, `username`, `uemail`, `upassword`, `uimg`) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $insertQuery);
            mysqli_stmt_bind_param($stmt, "sssss", $ufullname, $uname, $uemail, $hashedPassword, $imageDestination);
            $insertResult = mysqli_stmt_execute($stmt);

            if ($insertResult) {
                $registrationSuccess = true;

                // Automatically log in the user after registration
                $_SESSION['username'] = $uname;

                // Redirect to plans.php
                header("Location: plans.php");
                exit;
            } else {
                $registrationError = "Registration failed. Please try again later.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="Icon" href="imgs/logo2.png">
    <title>SignUp</title>
    <!-- Include CSS files -->
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
    .login-link {
        color: #468671;
    }
    </style>
</head>

<body class="d-flex align-items-center justify-content-center bg-dark">
    <div class="login-page m-auto">
        <div class="form">
            <?php if ($registrationSuccess): ?>
            <h1>Registration Successful</h1>
            <p>You can now <a href="plans.php">continue</a> to your plans.</p>
            <?php else: ?>
            <h1>Register</h1>
            <form method="post" enctype="multipart/form-data">
                <input type="text" placeholder="Full Name" name="ufullname"
                    value="<?php echo isset($ufullname) ? $ufullname : ''; ?>">
                <input type="text" placeholder="Username" name="uname"
                    value="<?php echo isset($uname) ? $uname : ''; ?>" required>
                <input type="email" placeholder="Email" name="uemail"
                    value="<?php echo isset($uemail) ? $uemail : ''; ?>" required>
                <input type="password" placeholder="Password" name="pw" required>
                <!-- Only display file input if a file is provided -->
                <input type="file" name="uimg">
                <input type="submit" value="Register" name="register">
            </form>
            <?php if ($registrationError): ?>
            <p><?php echo $registrationError; ?></p>
            <?php endif; ?>
            <p>Already have an account? <a class="login-link" href="login.php">Login</a></p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Include JavaScript files -->
    <script src="js/main.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php
ob_end_flush();
?>