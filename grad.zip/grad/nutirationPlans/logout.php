<?php
session_start();
session_destroy();

$redirectUrl = isset($_POST['redirect']) ? htmlspecialchars($_POST['redirect']) : 'index.php';
header("Location: $redirectUrl");
exit;
?>
