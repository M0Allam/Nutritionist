<?php
require('conn.php');
ob_start();


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Your existing HTML head content -->
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body class="d-flex align-items-center justify-content-center bg-dark">
    <div class="login-page m-auto">
        <div class="form">
            <form method="post">
                <h1>Reset Password</h1>
                <input type="password" placeholder="New Password" name="newPassword" required>
                <input type="password" placeholder="Confirm Password" name="confirmPassword" required>
                <input type="submit" value="Submit" name="submit">
            </form>
            <?php 
        if (isset($_GET['token'])) {
            $token = htmlspecialchars($_GET['token']);
            
            // Check if token exists in the database
            $selectQuery = "SELECT * FROM `password_reset` WHERE `token` = '$token'";
            $selectDone = mysqli_query($conn, $selectQuery);
            $data = mysqli_fetch_assoc($selectDone);
            
            if ($data) {
                // Token is valid, allow the user to reset their password
                // Display a form to enter a new password
                $email = $data['email'];
                $token = $data['token'];
        
                
            } else {
                echo "<p>Invalid token.</p>";
                exit;
            }
        } else {
            echo "<p>Token not provided.</p>";
            exit;
        }
        
        if (isset($_POST['submit'])) {
            $newPassword = htmlspecialchars($_POST['newPassword']);
            $confirmPassword = htmlspecialchars($_POST['confirmPassword']);
        
            if ($newPassword !== $confirmPassword) {
                echo "<p>Passwords not match.</p>";
            } else {
                // Update user's password in the database
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $updateQuery = "UPDATE `users` SET `upassword` = '$hashedPassword' WHERE `uemail` = '$email'";
                mysqli_query($conn, $updateQuery);
        
                // Delete the reset token from the database
                $deleteQuery = "DELETE FROM `password_reset` WHERE `token` = '$token'";
                mysqli_query($conn, $deleteQuery);
        
                // Display success message
                echo "<p>Password updated successfully.</p>";
                // Use JavaScript to delay the redirect
                echo "<script>setTimeout(function() { window.location.href = 'login.php'; }, 3000);</script>";
            }
        }
        ?>
        </div>
    </div>
    <!-- Your existing JavaScript files -->
</body>

</html>

<?php
ob_end_flush();
?>