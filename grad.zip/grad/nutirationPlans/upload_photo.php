<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

require('conn.php');

if(isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    if(isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['file']['tmp_name'];
        $file_name = $_FILES['file']['name']; // File name provided by the user

        // Introduce vulnerability: directly using the file name without proper sanitization
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        // Check if uploaded file is an image
        $blocked_extensions = array('php', 'php3', 'php4', 'php5', 'phtml', 'pht', 'phtm', 'cgi', 'exe', 'dll', 'bat', 'sh', 'pl');
        if(!in_array($file_ext, $blocked_extensions)) {
            // Generate a unique filename to avoid conflicts
            $new_filename = uniqid('', true) . '.' . $file_ext;

            // Move the uploaded file to the desired directory
            $upload_path = 'uploads/' . $new_filename;
            if(move_uploaded_file($file_tmp, $upload_path)) {
                // Update the user's profile photo in the database
                $sql = "UPDATE users SET uimg = '$upload_path' WHERE id = $user_id";
                if(mysqli_query($conn, $sql)) {
                    echo json_encode(array('success' => true, 'imageUrl' => $upload_path));
                    exit;
                } else {
                    echo json_encode(array('success' => false, 'message' => 'Error updating profile photo in database: ' . mysqli_error($conn)));
                    exit;
                }
            } else {
                echo json_encode(array('success' => false, 'message' => 'Error moving uploaded file.'));
                exit;
            }
        } else {
            echo json_encode(array('success' => false, 'message' => 'Invalid file format. JPG, PNG, JPEG and GIF only allowed.'));
            exit;
        }
    } else {
        echo json_encode(array('success' => false, 'message' => 'No file uploaded or an error occurred during upload.'));
        exit;
    }
} else {
    echo json_encode(array('success' => false, 'message' => 'User ID not found in session.'));
    exit;
}

?>