<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // User is not logged in, redirect to login page
    header("Location: login.php");
    exit; // Stop further execution
}

// If the user is logged in, display the content of the Plans.php page
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="css\bootstrap.min.css">
    <link rel="Icon" href="imgs/logo2.png">

    <title>Create a plan</title>

    <style>
    /* Add your CSS styles here */
    .d-none {
        display: none;
    }

    #downloadButton {
        display: none;
    }

    #downloadButtonDes {
        display: none;
    }

    /* Table Styling */
    .workout-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .workout-table th,
    .workout-table td {
        border: 1px solid #dddddd;
        text-align: center;
        padding: 8px;

    }

    .workout-table th {
        background-color: #f2f2f2;
    }

    /* Additional Styling */
    .workout-div {
        margin-top: 20px;
    }

    .workout-div li {
        margin-bottom: 10px;
    }

    .workout-div a {
        text-decoration: none;
        color: #007bff;
    }

    .workout-div a:hover {
        text-decoration: underline;
    }


    ]
    </style>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.3/jspdf.umd.min.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.3/html2pdf.bundle.min.js"></script>

    <!-- navbar section  -->

    <nav class="navbar navbar-expand-lg ">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php"><img src="imgs\logo.png" alt=""></a>
            <button class="hamburger" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">

                <div class="line1"></div>
                <div class="line2"></div>
                <div class="line3"></div>

            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php#Features">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">Blogs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="books.php">Books</a>
                    </li>
                    <?php if (isset($_SESSION["login"])) {
                        if ($_SESSION['login'] != "admin") { ?>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <?php echo ($_SESSION['login']); ?>
                        </a>
                    </li>
                    <?php } else { ?>
                    <li><a href="users.php">View Users</a></li>
                    <li><a href="editProducts.php">Edit Products</a></li>
                    <?php }
                    ?>
                    </li>
                    <li class="nav-item">
                        <form method="post" action="logout.php">
                            <input type="hidden" name="redirect" value="index.php">
                            <input class="login nav-link" type="submit" value="Logout" name="logout">
                        </form>
                    </li>
                    <?php } else { ?>
                    <li><a class="login nav-link" href="login.php">Login</a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </nav>


    <section id="Plans" class="container py-5">
        <div class="row d-flex flex-column justify-content-center align-items-center gap-3">
            <div class="col text-center">
                <h1 class="display-4">Plans</h1>
                <p class="lead">Create Your Free Nutrition Plan</p>
            </div>
        </div>

        <div class="d-block" id="firstForm">
            <form class="row g-3 fw-bold" id="userInfoForm">
                <div class="col-md-6">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" class="form-control" id="name" />
                </div>
                <div class="col-md-6">
                    <label for="age" class="form-label">Age</label>
                    <input type="number" class="form-control" id="age" />
                </div>

                <div class="col-md-6">
                    <label for="type" class="form-label">Type</label>
                    <select id="type" class="form-select">
                        <option selected disabled>Choose...</option>
                        <option value="gain">Gain Weight/Muscles</option>
                        <option value="lose">Lose weight/Fat</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="inputState" class="form-label">Activity Rate:</label>
                    <select id="inputState" class="form-select shadow-none">
                        <option selected>Choose...</option>
                        <option value="Not Active">Not Active</option>
                        <option value="Active">Active</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="inputState" class="form-label">Days for the gym</label>
                    <select id="inputState1" class="form-select shadow-none">
                        <option selected>Choose...</option>
                        <option value="3 Days">3 Days</option>
                        <option value="4 Days">4 Days</option>
                        <option value="5 Days">5 Days</option>
                    </select>
                </div>

                <div style="height: 20px;"></div> <!-- Blank line -->
                <div style="text-align: center;">
                    <button type="button" class="btn2" id="nextButton">Next</button>
                </div>
            </form>
        </div>

        <div id="secondForm" class="d-none">
            <form class="row g-3 fw-bold" id="nutritionForm">
                <div class="col-md-6">
                    <label for="height" class="form-label">Height</label>
                    <input type="number" class="form-control" id="height" />
                </div>
                <div class="col-md-6">
                    <label for="weight" class="form-label">Weight</label>
                    <input type="number" class="form-control" id="weight" />
                </div>
                <div class="col-md-6">
                    <label for="smm" class="form-label">Skeletal Muscle Mass (SMM)</label>
                    <input type="number" class="form-control" id="smm" />
                </div>

                <div class="col-md-6">
                    <label for="bodyFat" class="form-label">Body fat mass</label>
                    <input type="number" class="form-control" id="bodyFat" />
                </div>
                <div class="col-md-6">
                    <label for="bmi" class="form-label">BMR</label>
                    <input type="number" class="form-control" id="bmi" />
                </div>

                <div class="form-text mt-2" id="basic-addon4">After 12 days you can do another nutrition plan</div>

                <div style="text-align: center;">
                    <button type="submit" class="btn2">Submit</button>
                </div>
            </form>
        </div>
        <div style="height: 20px;"></div> <!-- Blank line -->
        <div style="text-align: center;">
            <h4>This Is Free Pdf For You, To Know The Food Calories List</h4>
            <div style="height: 20px;"></div> <!-- Blank line -->
            <button type="button" class="btn2" id="downloadButton2">Download PDF</button>
        </div>
        <div id="userInfo" class="d-none">
            <h2>User Information</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Type</th>
                        <th>Activity Rate</th>
                        <th>Days for the gym</th>
                        <th>Height</th>
                        <th>Weight</th>
                        <th>Skeletal Muscle Mass (SMM)</th>
                        <th>Body fat mass</th>
                        <th>BMR</th>
                    </tr>
                </thead>
                <tbody id="userInfoBody">
                    <!-- User info rows will be dynamically added here -->
                </tbody>
            </table>
        </div>

        <div id="nutritionPlan" class="d-none">
            <h2>Nutrition Plan</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Meal</th>
                        <th>Calories</th>
                        <th>Protein</th>
                        <th>Fat</th>
                        <th>Carbs</th>
                    </tr>
                </thead>
                <tbody id="mealPlanBody">
                    <!-- Meal plan rows will be dynamically added here -->
                </tbody>
            </table>
        </div>
        <div>
            <h3 id="downloadButtonDes">Download Your Free Nutiration Plan as Pdf Now !</h3>
            <button type="button" class="btn2" id="downloadButton">Download Plan</button>
        </div>

    </section>

    <script>
    document.getElementById('nextButton').addEventListener('click', function() {
        document.getElementById('firstForm').classList.add('d-none');
        document.getElementById('secondForm').classList.remove('d-none');
    });

    document.getElementById('nutritionForm').addEventListener('submit', function(event) {
        event.preventDefault();
        document.getElementById("downloadButton").style.display = "block";
        document.getElementById("downloadButtonDes").style.display = "block";

        // Retrieve user input values
        const name = document.getElementById('name').value;
        const age = parseInt(document.getElementById('age').value);
        const height = parseFloat(document.getElementById('height').value);
        const weight = parseFloat(document.getElementById('weight').value);
        const smm = parseFloat(document.getElementById('smm').value);
        const bodyFat = parseFloat(document.getElementById('bodyFat').value);
        const bmi = parseFloat(document.getElementById('bmi').value);
        const type = document.getElementById('type').value;
        const state = document.getElementById('inputState').value;
        const days = document.getElementById('inputState1').value;

        // Populate user information table
        populateUserInfo(name, age, type, state, days, height, weight, smm, bodyFat, bmi);

        // Calculate nutrition plan based on user input
        let mealPlan = [];
        if (type === 'gain') {
            // Calculate meal plan for gaining weight/muscles
            const BMR = bmi; // Dynamic BMR based on user input
            let output = BMR;
            if (state === 'Active') {
                output += 700; // Active
            } else if (state === 'Not Active') {
                output += 500; // Non-active
            }
            const breakfastCalories = Math.round(output * 0.325); // 32.5% of total
            const lunchCalories = Math.round(output * 0.375); // 37.5% of total
            const dinnerCalories = Math.round(output * 0.300); // 30% of total

            const breakfastCarbs = Math.round((breakfastCalories * 0.5) / 4); // 50% of calories from carbs
            const breakfastProtein = Math.round((breakfastCalories * 0.35) / 4); // 35% of calories from protein
            const breakfastFats = Math.round((breakfastCalories * 0.15) / 9); // 15% of calories from fats

            const lunchCarbs = Math.round((lunchCalories * 0.5) / 4);
            const lunchProtein = Math.round((lunchCalories * 0.35) / 4);
            const lunchFats = Math.round((lunchCalories * 0.15) / 9);

            const dinnerCarbs = Math.round((dinnerCalories * 0.5) / 4);
            const dinnerProtein = Math.round((dinnerCalories * 0.35) / 4);
            const dinnerFats = Math.round((dinnerCalories * 0.15) / 9);

            mealPlan = [{
                    meal: 'Breakfast',
                    calories: breakfastCalories,
                    protein: breakfastProtein,
                    fat: breakfastFats,
                    carbs: breakfastCarbs
                },
                {
                    meal: 'Lunch',
                    calories: lunchCalories,
                    protein: lunchProtein,
                    fat: lunchFats,
                    carbs: lunchCarbs
                },
                {
                    meal: 'Dinner',
                    calories: dinnerCalories,
                    protein: dinnerProtein,
                    fat: dinnerFats,
                    carbs: dinnerCarbs
                }
            ];
        } else if (type === 'lose') {
            // Calculate meal plan for losing weight/fat
            const BMR = bmi; // Dynamic BMR based on user input
            let output = BMR;
            if (state === 'Active') {
                output -= 500; // Active
            } else if (state === 'Not Active') {
                output -= 300; // Non-active
            }
            const breakfastCalories = Math.round(output * 0.30); // 30% of total
            const lunchCalories = Math.round(output * 0.35); // 35% of total
            const dinnerCalories = Math.round(output * 0.35); // 35% of total

            const breakfastCarbs = Math.round((breakfastCalories * 0.45) / 4); // 45% of calories from carbs
            const breakfastProtein = Math.round((breakfastCalories * 0.40) / 4); // 30% of calories from protein
            const breakfastFats = Math.round((breakfastCalories * 0.15) / 9); // 25% of calories from fats

            const lunchCarbs = Math.round((lunchCalories * 0.45) / 4);
            const lunchProtein = Math.round((lunchCalories * 0.40) / 4);
            const lunchFats = Math.round((lunchCalories * 0.15) / 9);

            const dinnerCarbs = Math.round((dinnerCalories * 0.45) / 4);
            const dinnerProtein = Math.round((dinnerCalories * 0.40) / 4);
            const dinnerFats = Math.round((dinnerCalories * 0.15) / 9);

            mealPlan = [{
                    meal: 'Breakfast',
                    calories: breakfastCalories,
                    protein: breakfastProtein,
                    fat: breakfastFats,
                    carbs: breakfastCarbs
                },
                {
                    meal: 'Lunch',
                    calories: lunchCalories,
                    protein: lunchProtein,
                    fat: lunchFats,
                    carbs: lunchCarbs
                },
                {
                    meal: 'Dinner',
                    calories: dinnerCalories,
                    protein: dinnerProtein,
                    fat: dinnerFats,
                    carbs: dinnerCarbs
                }
            ];
        }

        // Display nutrition plan
        displayMealPlan(mealPlan);
        displayWorkoutPlaylists(days); // Display workout playlists based on selected days
        document.getElementById('secondForm').classList.add('d-none');
        document.getElementById('nutritionPlan').classList.remove('d-none');
    });

    function populateUserInfo(name, age, type, state, days, height, weight, smm, bodyFat, bmi) {
        const userInfoBody = document.getElementById('userInfoBody');
        userInfoBody.innerHTML = ''; // Clear existing rows

        const row = document.createElement('tr');
        row.innerHTML = `
      <td>${name}</td>
      <td>${age}</td>
      <td>${type}</td>
      <td>${state}</td>
      <td>${days}</td>
      <td>${height}</td>
      <td>${weight}</td>
      <td>${smm}</td>
      <td>${bodyFat}</td>
      <td>${bmi}</td>
    `;
        userInfoBody.appendChild(row);

        document.getElementById('userInfo').classList.remove('d-none');
    }

    function displayMealPlan(mealPlan) {
        const mealPlanBody = document.getElementById('mealPlanBody');
        mealPlanBody.innerHTML = ''; // Clear existing rows

        mealPlan.forEach(meal => {
            const row = document.createElement('tr');
            row.innerHTML = `
        <td>${meal.meal}</td>
        <td>${meal.calories}</td>
        <td>${meal.protein}</td>
        <td>${meal.fat}</td>
        <td>${meal.carbs}</td>
      `;
            mealPlanBody.appendChild(row);
        });
    }

    function displayWorkoutPlaylists(days) {
        const workoutDiv = document.createElement('div');
        workoutDiv.className = 'workout-div';
        workoutDiv.innerHTML = '';

        if (days === '5 Days') {
            // Display workout playlists for 4 days
            const playlists = [
                "Here's the best workout plan for 4 days and repeat any workout on the 5th day",
                "https://youtube.com/playlist?list=PLkVVAH-mp4DMbGwspoi21B7tA8WS9h1kg&si=L2Dp28_0b-reKU3-",
                "https://youtube.com/playlist?list=PLkVVAH-mp4DPJ2U7nhwkSTDUl1HOjJkqV&si=c9Q5Po21ggLO_JUh",
                "https://youtube.com/playlist?list=PLkVVAH-mp4DPMXwO7EB2DPdXK-dg3x7WB&si=s4YTKk9yvUj0EMgy",
                "https://youtube.com/playlist?list=PLkVVAH-mp4DNBHAjGRu_smvddIh2DVNHU&si=yqv68baJhiU7qbP3",
            ];

            const table = document.createElement('table');
            table.className = 'workout-table';
            const tbody = document.createElement('tbody');

            playlists.forEach((playlist, index) => {
                const row = document.createElement('tr');
                const cell = document.createElement('td');
                if (index === 0) {
                    cell.textContent = playlist;
                } else {
                    const link = document.createElement('a');
                    link.setAttribute('href', playlist);
                    link.setAttribute('target', '_blank');
                    link.textContent = `Day ${index } Workout Playlist`;
                    cell.appendChild(link);
                }
                row.appendChild(cell);
                tbody.appendChild(row);
            });

            table.appendChild(tbody);
            workoutDiv.appendChild(table);
        }
        if (days === '4 Days') {
            // Display workout playlists for 4 days
            const playlists = [
                "Here's the best workout plan for 4 days",
                "https://youtube.com/playlist?list=PLkVVAH-mp4DMbGwspoi21B7tA8WS9h1kg&si=L2Dp28_0b-reKU3-",
                "https://youtube.com/playlist?list=PLkVVAH-mp4DPJ2U7nhwkSTDUl1HOjJkqV&si=c9Q5Po21ggLO_JUh",
                "https://youtube.com/playlist?list=PLkVVAH-mp4DPMXwO7EB2DPdXK-dg3x7WB&si=s4YTKk9yvUj0EMgy",
                "https://youtube.com/playlist?list=PLkVVAH-mp4DNBHAjGRu_smvddIh2DVNHU&si=yqv68baJhiU7qbP3",
            ];

            const table = document.createElement('table');
            table.className = 'workout-table';
            const tbody = document.createElement('tbody');

            playlists.forEach((playlist, index) => {
                const row = document.createElement('tr');
                const cell = document.createElement('td');
                if (index === 0) {
                    cell.textContent = playlist;
                } else {
                    const link = document.createElement('a');
                    link.setAttribute('href', playlist);
                    link.setAttribute('target', '_blank');
                    link.textContent = `Day ${index } Workout Playlist`;
                    cell.appendChild(link);
                }
                row.appendChild(cell);
                tbody.appendChild(row);
            });

            table.appendChild(tbody);
            workoutDiv.appendChild(table);
        }
        if (days === '3 Days') {
            // Display workout playlists for 3 days
            const playlists = [
                "Here's the best workouts plan for 3 days",
                "https://youtube.com/playlist?list=PLkVVAH-mp4DMbGwspoi21B7tA8WS9h1kg&si=L2Dp28_0b-reKU3-",
                "https://youtube.com/playlist?list=PLkVVAH-mp4DPJ2U7nhwkSTDUl1HOjJkqV&si=c9Q5Po21ggLO_JUh",
                "https://youtube.com/playlist?list=PLkVVAH-mp4DPMXwO7EB2DPdXK-dg3x7WB&si=s4YTKk9yvUj0EMgy",
            ];

            const table = document.createElement('table');
            table.className = 'workout-table';
            const tbody = document.createElement('tbody');

            playlists.forEach((playlist, index) => {
                const row = document.createElement('tr');
                const cell = document.createElement('td');
                if (index === 0) {
                    cell.textContent = playlist;
                } else {
                    const link = document.createElement('a');
                    link.setAttribute('href', playlist);
                    link.setAttribute('target', '_blank');
                    link.textContent = `Day ${index } Workout Playlist`;
                    cell.appendChild(link);
                }
                row.appendChild(cell);
                tbody.appendChild(row);
            });

            table.appendChild(tbody);
            workoutDiv.appendChild(table);
        }
        document.getElementById('nutritionPlan').appendChild(workoutDiv);
    }


    document.getElementById('downloadButton').addEventListener('click', function() {
        const element = document.getElementById('userInfo').cloneNode(true); // Clone the user info element
        const nutritionPlan = document.getElementById('nutritionPlan').cloneNode(
            true); // Clone the nutrition plan element

        // Combine user info and nutrition plan in a single div
        const combinedDiv = document.createElement('div');
        combinedDiv.appendChild(element);
        combinedDiv.appendChild(nutritionPlan);

        // Convert combinedDiv to PDF
        html2pdf()
            .from(combinedDiv)
            .save();
    });
    document.getElementById('downloadButton2').addEventListener('click', function() {
        // Provide the path to your pre-existing PDF file
        const pdfFilePath = 'Food Calories List (1).pdf';

        // Create an anchor element
        const downloadLink = document.createElement('a');

        // Set the href attribute to the path of the PDF file
        downloadLink.href = pdfFilePath;

        // Set the download attribute to the desired filename for the downloaded file
        downloadLink.download = 'free.pdf';

        // Append the anchor element to the document body
        document.body.appendChild(downloadLink);

        // Trigger a click event on the anchor element to start the download
        downloadLink.click();

        // Remove the anchor element from the document body
        document.body.removeChild(downloadLink);
    });
    </script>
    </body>