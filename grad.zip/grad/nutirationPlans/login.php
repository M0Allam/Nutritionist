<?php
require('conn.php');
ob_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="Icon" href="imgs/logo2.png">
    <title>Login</title>
    <!-- Include CSS files -->
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
    p {
        padding: 10px;
        /* Add some padding for spacing */
        border-radius: 5px;
        /* Rounded corners */
        font-family: Arial, sans-serif;
        /* Font family */
        font-size: 16px;
        /* Font size */
        color: red;
        margin-top: 10px;
    }
    </style>
</head>


<body class="d-flex align-items-center justify-content-center bg-dark">
    <div class="login-page m-auto">
        <div class="form">
            <form method="post">
                <h1>Login</h1>
                <input type="text" placeholder="Username" name="uname">
                <input type="password" placeholder="Password" name="pw">
                <input type="submit" value="Login" name="signin">
                <p class="message"><a href="forgot_password.php">Forgot Password?</a></p>
                <p class="message">Not registered?<a href="signUp.php">Create an account</a></p>
            </form>
            <?php
            if (isset($_POST['signin'])) {
                $uname = htmlspecialchars($_POST['uname']);
                $pw = htmlspecialchars($_POST['pw']);
                
                // Check if username exists in the database
                $selectQuery = "SELECT * FROM `users` WHERE `username` = '$uname'";
                $selectDone = mysqli_query($conn, $selectQuery);
                $data = mysqli_fetch_assoc($selectDone);
                
        if ($data) {
               // Verify the entered password with the hashed password from the database
               if (password_verify($pw, $data['upassword'])) {
               // Generate OTP and send it
                   $otp = mt_rand(100000, 999999);
            
                        // Update the user's OTP in the database
                        $updateQuery = "UPDATE `users` SET `otp` = '$otp' WHERE `username` = '$uname'";
                        mysqli_query($conn, $updateQuery);
            
                        // Send mail using PHP's mail function or a library like PHPMailer
                        // Example using PHP's mail function:
                        // mail($to, $subject, $message);
                        




                    
                        
                        // Store OTP in session for verification
                        session_start();
                        $_SESSION['otp'] = $otp;
                        $_SESSION['user_id'] = $data['id']; // Save user ID in session
                        
                        // Redirect user to OTP verification page
                        header("Location: otp_verification.php?username=$uname");
                        exit;
                    } else {
                        echo "<p>Wrong password</p>";
                    }
                } else {
                    echo "<p>Username not Found</p>";
                }
            }
            ?>
        </div>
    </div>

    <!-- Include JavaScript files -->
    <script src="js/main.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php

ob_end_flush();

?>