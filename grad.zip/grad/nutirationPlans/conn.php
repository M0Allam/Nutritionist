
<?php
$conn = new mysqli('localhost' , 'root' , '' , 'nutiration-project');
?>