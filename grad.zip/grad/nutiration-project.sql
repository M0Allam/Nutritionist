-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2024 at 11:27 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nutiration-project`
--

-- --------------------------------------------------------

--
-- Table structure for table `password_reset`
--

CREATE TABLE `password_reset` (
  `rid` int(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `reset_link` varchar(255) NOT NULL,
  `timestamp` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password_reset`
--

INSERT INTO `password_reset` (`rid`, `email`, `token`, `reset_link`, `timestamp`) VALUES
(1, 'shady@gmail.com', 'd28dacaae48e6cd8c806edd7dda2b4096e817449ead53d5a6a7fcfe99b767579', '', '0000-00-00'),
(2, 'shady@gmail.com', 'http://localhost/nutirationPlans/reset_password.php?token=ab848ab6680e41a9dfa395f1469c6cb3519b39fa97be3c8b28ee42152f3a25ee', '', '0000-00-00'),
(3, 'shady@gmail.com', 'localhost/nutirationPlans/reset_password.php?token=0b242701a209666c155bbd94486cb573103859d778e86c24edae6e7184fa073a', '', '0000-00-00'),
(4, 'shady@gmail.com', 'a3a2978b7a943015a9db2b8f3175b0af5b55028c52d3d78647e13dddd8b41865', '', '0000-00-00'),
(5, 'shady@gmail.com', '4bdff86c78c4777d67ef1064dceb214e5c635c1a241f6ad5e4d0320ab7e75ef2', '', '0000-00-00'),
(6, 'shady@gmail.com', '9a6449c55861c0267b31f59375bf9b2f4fad53130f70124692dd407d9dc7231f', '', '0000-00-00'),
(7, 'allam0x1@gmail.com', 'd931965eac5d0bd73792b79eff55a762e244bd3579a8a10c54fda3c038916eb1', '', '0000-00-00'),
(8, 'allam0x1@gmail.com', 'a32879a7b1536b0fddd2b9af8291f6234cfa5468049b78385f242e479009efb1', '', '0000-00-00'),
(9, 'allam0x1@gmail.com', 'cdd987a1dc8ee3dd32fc9fdb4cdeb4a3092fe221856d12b3dcfc05941ef580ef', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `ufullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `uemail` varchar(255) NOT NULL,
  `upassword` varchar(255) NOT NULL,
  `uimg` varchar(255) NOT NULL,
  `otp` varchar(255) NOT NULL,
  `reset_token` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ufullname`, `username`, `uemail`, `upassword`, `uimg`, `otp`, `reset_token`) VALUES
(1, 'allam', 'allam12', 'allam0x1@gmail.com', '12345', '', '', ''),
(3, 'testallamdas', 'ha', 'allam0x1d20021@gmail.com', '$2y$10$5lj66S6196CodQn6Ky4tWu51AWmp8R1dX6Z8uQ1UCOzVnx/fq95mu', 'uploads/65fde7333605c3.05036263.jpg', '', ''),
(4, 'test', 'test', 'allam@gmail.com', '$2y$10$O2zIjJf23OC99v8y2mcyVuD673tSjtPnlfuQ4/Fv7oYSNETBi8ir2', 'uploads/6bbf2331-4a00-41e2-a5ef-ba146fbd3858.jpg', '', ''),
(5, 'allam123', 'ddss', 'allam0x12525@gmail.com', '$2y$10$xwBNql.i0sIFRaJ0aOqVyubdCUqrmKySDgIjn9k582XZ0WBKZ8kz2', 'uploads/6611c2773342d6.15833033.jpg', '', 'http://localhost/nutirationPlans/reset_password.php?token=e755e34ec2eed473cd5074c8b57af237de34cb536089dee227df2501d1c0bb89'),
(6, 'Last test', 'allam', 'allam0x1000@gmail.com', '$2y$10$pTciGIK0aqGCF8Rflvo1nO4ta/CQG5S4iRrALrVLkHBnasPSdd88C', 'uploads/6bbf2331-4a00-41e2-a5ef-ba146fbd3858.jpg', '', 'http://localhost/nutirationPlans/reset_password.php?token=5e5bf6c0c8b59bba88023a6e378faa79e8b7230a5e707d90d6629e51e66d87ac'),
(7, '3trbb_allam', 'shady_5', 'shady@gmail.com', '$2y$10$eb1sN5DU2RgwdA3DgD7qFOhWAxcfTXljYaeUjBL.v7m5H0ZFKbswC', 'uploads/6603833ecb12b7.28351243.png', '', 'http://localhost/nutirationPlans/reset_password.php?token=8a619508a7f5381744123a8040124d937200a35e736b07907af8211a3c45db85'),
(8, '&lt;h1&gt;Mohamed&lt;/h1&gt;', 'allamNew1', 'allam0x1200001@gmail.com', '$2y$10$xeZVZ9ypVcfGJX73RAbeWuRqKpd9WQ.fswOU6Ja/PwlzzlHz0JXV6', 'uploads/6bbf2331-4a00-41e2-a5ef-ba146fbd3858.jpg', '', ''),
(9, 'shady', 'shady', 'shady@gmail.com', '$2y$10$QqvM.NOjFEhjfp3KDFwSKeUqteRPcaQDW8Qyal0OGP4G1z8fFlAbm', 'uploads/116319184.jpg', '', ''),
(10, 'new new', 'allam10', 'allam@gmail.com', '$2y$10$CH66t0Z0FY9wkFLF1S/n5OFHtzYGMlqzH2ybVIs0I6a7kwwyZc2T2', 'uploads/images.jpg', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `password_reset`
--
ALTER TABLE `password_reset`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `password_reset`
--
ALTER TABLE `password_reset`
  MODIFY `rid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
