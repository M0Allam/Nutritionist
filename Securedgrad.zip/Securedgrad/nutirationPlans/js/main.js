const hamburger = document.querySelector(".hamburger");
const navLinks = document.querySelector(".nav");
const links = document.querySelectorAll(".nav li");

hamburger.addEventListener('click', () => {
    //Animate Links
    navLinks.classList.toggle("open");
    links.forEach(link => {
        link.classList.toggle("fade");
    });

    //Hamburger Animation
    hamburger.classList.toggle("toggle");
});


function myFunction() {
    const element = document.getElementById("firstForm");  // Get the DIV element
    element.classList.remove("d-block"); // Remove mystyle class from DIV
    element.classList.add("d-none"); // Add newone class to DIV
     
    const x= document.getElementById("secoundForm");  // Get the DIV element
    x.classList.remove("d-none"); // Remove mystyle class from DIV
    x.classList.add("d-bolck"); // Add newone class to DIV
}




function firstForm() {
    const element = document.getElementById("firstForm");  // Get the DIV element
    element.classList.remove("d-none"); // Remove mystyle class from DIV
    element.classList.add("d-block"); // Add newone class to DIV
    // to hide secound form 
    const hide = document.getElementById("secoundForm");  // Get the DIV element
    hide.classList.remove("d-block"); // Remove mystyle class from DIV
    hide.classList.add("d-none"); // Add newone class to DIV
}


document.addEventListener('DOMContentLoaded', function() {
  var form = document.getElementById('user-info-form');
  form.addEventListener('submit', function(event) {
    event.preventDefault();
    var height = document.getElementById('height').value;
    var weight = document.getElementById('weight').value;
    var age = document.getElementById('age').value;
    var SMM = document.getElementById('SMM').value;
    var BodyFatMass = document.getElementById('BodyFatMass').value;
    var BMI = document.getElementById('BMI').value;

    var formData = {
      height: height,
      weight: weight,
      age: age,
      SMM: SMM,
      BodyFatMass: BodyFatMass,
      BMI: BMI
    };

    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'https://api.openai.com/v1/engines/text-davinci-002/completions');
    xhr.setRequestHeader('Authorization', 'Bearer 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');
    xhr.setRequestHeader('Content-Type', 'application/json');

    xhr.onload = function() {
      if (xhr.status === 200) {
        var response = JSON.parse(xhr.responseText);
        var chatResponse = response.choices[0].text.trim();
        document.getElementById('chat-response').innerHTML = '<p>' + chatResponse + '</p>';
      } else {
        console.error('Error:', xhr.statusText);
      }
    };

    xhr.onerror = function() {
      console.error('Request failed');
    };

    xhr.send(JSON.stringify({
      prompt: 'User information: Height ' + formData.height + ' Weight ' + formData.weight + ' Age ' + formData.age 
     + 'SMM' + formData.SMM + 'BodyFatMass' + formData.BodyFatMass + ' BMI ' + formData.BMI + '\nResponse:'
    }));
  });
});


