<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="css\bootstrap.min.css">
    <link rel="Icon" href="imgs/logo2.png">

    <title>Blogs</title>

    <style>
    /* Add your CSS styles here */
    .d-none {
        display: none;
    }

    #downloadButton {
        display: none;
    }

    #downloadButtonDes {
        display: none;
    }

    /* Table Styling */
    .workout-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .workout-table th,
    .workout-table td {
        border: 1px solid #dddddd;
        text-align: center;
        padding: 8px;

    }

    .workout-table th {
        background-color: #f2f2f2;
    }

    /* Additional Styling */
    .workout-div {
        margin-top: 20px;
    }

    .workout-div li {
        margin-bottom: 10px;
    }

    .workout-div a {
        text-decoration: none;
        color: #007bff;
    }

    .workout-div a:hover {
        text-decoration: underline;
    }
    </style>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.3/jspdf.umd.min.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.3/html2pdf.bundle.min.js"></script>

</head>

<body>


    <!-- navbar section  -->
    <nav class="navbar navbar-expand-lg ">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php"><img src="imgs\logo.png" alt=""></a>
            <button class="hamburger" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">

                <div class="line1"></div>
                <div class="line2"></div>
                <div class="line3"></div>

            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php#Features">Features</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="plans.php">Plans</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="books.php">Books</a>
                    </li>
                    <?php if (isset($_SESSION["login"])) { ?>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <?php echo $_SESSION['login']; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <form method="post" action="logout.php">
                            <input type="hidden" name="redirect" value="index.php">
                            <input class="login nav-link" type="submit" value="Logout" name="logout">
                        </form>
                    </li>
                    <?php } else { ?>

                    <?php } ?>
                </ul>
            </div>
        </div>
    </nav>


    <!-- our blogs section -->


    <section id="Blogs" class="container d-flex flex-column justify-content-center align-items-start gap-5">
        <div class="row d-flex flex-column justify-content-center align-items-center gap-3">
            <div class="col text-center">
                <h1 class="display-4">Our Blogs</h1>
                <p class="lead">Our blog is a treasure trove of informative and engaging articles written by our team of
                    nutritionists, dietitians, and wellness experts. </p>
                <p class="lead">Here's what you can expect from our blog.</p>
            </div>
        </div>
        <div class="row d-flex justify-content-center gap-4">
            <!-- Weight Loss Blog Card -->
            <a href="https://www.medicalnewstoday.com/articles/303409" class="col-md-5 mb-3 text-decoration-none"
                target="_blank">
                <div class="card rounded h-100">
                    <img src="./imgs/our blog(1).png" class="blog card-img-top rounded-top" alt="Blog Post Image 1">
                    <div class="blogs card-body d-flex flex-column justify-content-between">
                        <div class="d-flex flex-column gap-2">
                            <h5 class="card-title">Weight Loss</h5>
                            <p class="card-text">Discover how staying hydrated can support your weight loss goals and
                                improve overall health.</p>
                        </div>
                        <div class="d-flex flex-row justify-content-between align-items-center">
                            <div class="d-flex align-items-center gap-2">
                                <img src="imgs/Image (8).png" class="rounded-circle" alt="Author Avatar">
                                <div class="text-start">
                                    <p class="mb-0 mt-3">Emily Johnson</p>
                                    <small class="text-muted">23 May 2023 - 5 min read</small>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <img src="imgs/Icon Container (6).png" alt="Icon">
                                <img src="imgs/Icon Container (7).png" alt="Icon">
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            <!-- Mindful Eating Blog Card -->
            <a href="https://www.hsph.harvard.edu/nutritionsource/mindful-eating/"
                class="col-md-5 mb-3 text-decoration-none" target="_blank">
                <div class="card shadow rounded h-100">
                    <img src="imgs/our blog (2).png" class="blog card-img-top rounded-top" alt="Blog Post Image 2">
                    <div class="blogs card-body d-flex flex-column justify-content-between">
                        <div class="d-flex flex-column gap-2">
                            <h5 class="card-title">Mindful Eating</h5>
                            <p class="card-text">Cultivating a Healthy Relationship with Food</p>
                        </div>
                        <div class="d-flex flex-row justify-content-between align-items-center">
                            <div class="d-flex align-items-center gap-2">
                                <img src="imgs/Image (9).png" class="rounded-circle" alt="Author Avatar">
                                <div class="text-start">
                                    <p class="mb-0">Sarah Thompson</p>
                                    <small class="text-muted">23 May 2023 - 5 min read</small>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <img src="imgs/Icon Container (6).png" alt="Icon">
                                <img src="imgs/Icon Container (7).png" alt="Icon">
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            <!-- Understanding Macronutrients Blog Card -->
            <a href="https://avitahealth.org/health-library/macronutrients-a-simple-guide-to-macros/"
                class="col-md-5 mb-3 text-decoration-none" target="_blank">
                <div class="card shadow rounded h-100">
                    <img src="imgs/our blog (3).png" class="blog card-img-top rounded-top" alt="Blog Post Image 3">
                    <div class="blogs card-body d-flex flex-column justify-content-between">
                        <div class="d-flex flex-column gap-2">
                            <h5 class="card-title">Understanding Macronutrients</h5>
                            <p class="card-text">Carbohydrates, Proteins, and Fats</p>
                        </div>
                        <div class="d-flex flex-row justify-content-between align-items-center">
                            <div class="d-flex align-items-center gap-2">
                                <img src="imgs/Image (10).png" class="rounded-circle" alt="Author Avatar">
                                <div class="text-start">
                                    <p class="mb-0">Mark Wilson</p>
                                    <small class="text-muted">23 May 2023 - 5 min read</small>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <img src="imgs/Icon Container (6).png" alt="Icon">
                                <img src="imgs/Icon Container (7).png" alt="Icon">
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            <!-- Healthy Snacks on the Go Blog Card -->
            <a href="https://www.healthline.com/nutrition/healthy-high-protein-snacks"
                class="col-md-5 mb-3 text-decoration-none" target="_blank">
                <div class="card shadow rounded h-100">
                    <img src="imgs/our blog (4).png" class="blog card-img-top rounded-top" alt="Blog Post Image 4">
                    <div class="blogs card-body d-flex flex-column justify-content-between">
                        <div class="d-flex flex-column gap-2">
                            <h5 class="card-title">Healthy Snacks on the Go</h5>
                            <p class="card-text">Quick and Nutritious Options</p>
                        </div>
                        <div class="d-flex flex-row justify-content-between align-items-center">
                            <div class="d-flex align-items-center gap-2">
                                <img src="imgs/Image (11).png" class="rounded-circle" alt="Author Avatar">
                                <div class="text-start">
                                    <p class="mb-0 mt-3">Emily Johnson</p>
                                    <small class="text-muted">23 May 2023 - 5 min read</small>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <img src="imgs/Icon Container (6).png" alt="Icon">
                                <img src="imgs/Icon Container (7).png" alt="Icon">
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </section>

</body>

</html>