<?php
require('conn.php');
ob_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Your existing HTML head content -->

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="icon" href="imgs/logo2.png"> <!-- "icon" should be lowercase -->
    <style>
    p {
        padding: 10px;
        border-radius: 5px;
        font-family: Arial, sans-serif;
        font-size: 16px;
        color: green;
        margin-top: 15px;
    }
    </style>
</head>

<body class="d-flex align-items-center justify-content-center bg-dark">
    <div class="login-page m-auto">
        <div class="form">
            <form method="post">
                <h1>Forgot Password</h1>
                <input type="email" placeholder="Email" name="email" required>
                <input type="submit" value="Reset Password" name="reset">
                <p class="message">Back to login? <a href="login.php">Login</a></p> <!-- Capitalize "Back" -->
            </form>
            <?php
            if (isset($_POST['reset'])) {
                $email = htmlspecialchars($_POST['email']);
                
                // Check if email exists in the database
                $selectQuery = "SELECT * FROM `users` WHERE `uemail` = '$email'";
                $selectDone = mysqli_query($conn, $selectQuery);
                $data = mysqli_fetch_assoc($selectDone);
                
                if ($data) {
                    // Generate a unique token for password reset
                    $token = bin2hex(random_bytes(32));
                
                    // Construct the reset link with token
                    $link = "http://localhost/grad/nutirationPlans/reset_password.php?token=";
                    $resetLink = $link . $token;
                
                    // Store the token and link in the database along with the user's email and a timestamp
                    $timestamp = time();
                    $insertQuery = "INSERT INTO `password_reset` (`email`, `token`, `reset_link`, `timestamp`) VALUES ('$email', '$token', '$resetLink', '$timestamp')";
                    mysqli_query($conn, $insertQuery);
                
                    // Send mail with password reset link
                    $subject = "Password Reset Request";
                    $message = "To reset your password, click the link below:\n\n$resetLink";
                    // mail($email, $subject, $message);
                
                    echo "<p>Password reset link sent to your email.</p>";
                    
                    // Redirect after a delay
                    header('refresh:3; url=login.php');
                    exit(); // Stop further execution
                }
            }
            ?>
        </div>
    </div>
</body>

</html>

<?php
ob_end_flush();
?>