<?php
require('conn.php');
ob_start();

// Initialize variables for success and redirect messages
$successMessage = '';
$redirectMessage = '';

if (isset($_GET['token'])) {
    $token = htmlspecialchars($_GET['token']);
    
    // Check if token exists in the database
    $selectQuery = "SELECT * FROM `password_reset` WHERE `token` = '$token'";
    $selectDone = mysqli_query($conn, $selectQuery);
    $data = mysqli_fetch_assoc($selectDone);
    
    if ($data) {
        // Token is valid, allow the user to reset their password
        // Display a form to enter a new password
        $email = $data['email'];
        $token = $data['token'];
    } else {
        echo "<p class='error-message'>Invalid token.</p>";
        exit;
    }
} else {
    echo "<p class='error-message'>Token not provided.</p>";
    exit;
}

if (isset($_POST['submit'])) {
    $newPassword = htmlspecialchars($_POST['newPassword']);
    $confirmPassword = htmlspecialchars($_POST['confirmPassword']);
    
    // Password policy criteria
    $passwordLength = strlen($newPassword);
    $validPassword = preg_match('/^[a-zA-Z0-9!@#$%^&*()_-]+$/', $newPassword);
    $number    = preg_match('@[0-9]@', $newPassword);

    // Check if the password meets the criteria
    if (!$validPassword || !$number || $passwordLength < 8) {
        $successMessage = "<p class='error-message'>Password must be at least 8 characters long and contain only letters (lowercase or uppercase), numbers, and optional special characters.</p>";
    } elseif ($newPassword !== $confirmPassword) {
        $successMessage = "<p class='error-message'>Passwords do not match.</p>";
    } else {
        // Update user's password in the database
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $updateQuery = "UPDATE `users` SET `upassword` = '$hashedPassword' WHERE `uemail` = '$email'";
        mysqli_query($conn, $updateQuery);

        // Delete the reset token from the database
        $deleteQuery = "DELETE FROM `password_reset` WHERE `token` = '$token'";
        mysqli_query($conn, $deleteQuery);

        $successMessage = "<p class='success-message'>Password updated successfully.</p>";
        $redirectMessage = "<p class='redirect-message'>You will be redirected to the login page shortly.</p>";

        // Do not redirect immediately, let the message be displayed
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Your existing HTML head content -->
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="Icon" href="imgs/logo2.png">
    <style>
    .success-message {
        color: green;
    }

    .redirect-message {
        color: blue;
    }
    </style>
</head>

<body class="d-flex align-items-center justify-content-center bg-dark">
    <div class="login-page m-auto">
        <div class="form">
            <form method="post">
                <h1>Reset Password</h1>
                <input type="password" placeholder="New Password" name="newPassword" required>
                <input type="password" placeholder="Confirm Password" name="confirmPassword" required>
                <input type="submit" value="Submit" name="submit">
            </form>
            <?php echo $successMessage; ?>
            <?php echo $redirectMessage; ?>

            <?php if (!empty($redirectMessage)): ?>
            <meta http-equiv="refresh" content="3;url=login.php">
            <?php endif; ?>
        </div>
    </div>
    <!-- Your existing JavaScript files -->
</body>

</html>

<?php
ob_end_flush();
?>