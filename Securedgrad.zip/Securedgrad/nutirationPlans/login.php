<?php
require('conn.php');
session_start();
ob_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="Icon" href="imgs/logo2.png">
    <title>Login</title>
    <!-- Include CSS files -->
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
    p {
        padding: 10px;
        border-radius: 5px;
        font-family: Arial, sans-serif;
        font-size: 16px;
        color: red;
        margin-top: 10px;
    }
    </style>
</head>

<body class="d-flex align-items-center justify-content-center bg-dark">
    <div class="login-page m-auto">
        <div class="form">
            <form method="post">
                <h1>Login</h1>
                <input type="text" placeholder="Username" name="uname" required>
                <input type="password" placeholder="Password" name="pw" required>
                <input type="submit" value="Login" name="signin">
                <p class="message"><a href="forgot_password.php">Forgot Password?</a></p>
                <p class="message">Not registered?<a href="signUp.php">Create an account</a></p>
            </form>
            <?php
            if (isset($_POST['signin'])) {
                $uname = htmlspecialchars($_POST['uname']);
                $pw = htmlspecialchars($_POST['pw']);
                
                // Check if username exists in the database
                $stmt = $conn->prepare("SELECT * FROM `users` WHERE `username` = ?");
                $stmt->bind_param("s", $uname);
                $stmt->execute();
                $result = $stmt->get_result();
                $data = $result->fetch_assoc();
                $stmt->close();
                
                
                if ($data) {
                    // Verify the entered password with the hashed password from the database
                    if (password_verify($pw, $data['upassword'])) {
                        // Generate OTP and send it
                        $otp = mt_rand(10000000, 99999999);
                        $otp_creation_time = date("Y-m-d H:i:s");
            
                        // Update the user's OTP and OTP creation time in the database
                        $stmt = $conn->prepare("UPDATE `users` SET `otp` = ?, `otp_creation_time` = ? WHERE `username` = ?");
                        $stmt->bind_param("iss", $otp, $otp_creation_time, $uname);
                        $stmt->execute();
                        $stmt->close();
            
                        // Send mail using PHP's mail function or a library like PHPMailer
                        // Example using PHP's mail function:
                        // mail($to, $subject, $message);
                        
                        // Store OTP and username in session for verification
                        $_SESSION['otp'] = $otp;
                        $_SESSION['username'] = $uname; // Save username in session
                        $_SESSION['user_id'] = $data['id']; // Save user ID in session
                        
                        // Redirect user to OTP verification page
                        header("Location: otp_verification.php");
                        exit;
                    } else {
                        echo "<p>Invalid Username or Password</p>";
                    }
                }
            }
            ?>
        </div>
    </div>

    <!-- Include JavaScript files -->
    <script src="js/main.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php
ob_end_flush();
?>