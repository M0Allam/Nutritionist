<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="css\bootstrap.min.css">
    <link rel="Icon" href="imgs/logo2.png">
    <title>Books Store</title>

    <style>
    /* Add your CSS styles here */
    .d-none {
        display: none;
    }

    #downloadButton {
        display: none;
    }

    #downloadButtonDes {
        display: none;
    }

    /* Table Styling */
    .workout-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .workout-table th,
    .workout-table td {
        border: 1px solid #dddddd;
        text-align: center;
        padding: 8px;
    }

    .workout-table th {
        background-color: #f2f2f2;
    }

    /* Additional Styling */
    .workout-div {
        margin-top: 20px;
    }

    .workout-div li {
        margin-bottom: 10px;
    }

    .workout-div a {
        text-decoration: none;
        color: #007bff;
    }

    .workout-div a:hover {
        text-decoration: underline;
    }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg ">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php"><img src="imgs\logo.png" alt=""></a>
            <button class="hamburger" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">

                <div class="line1"></div>
                <div class="line2"></div>
                <div class="line3"></div>

            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php#Features">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="plans.php">Plans</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">Blogs</a>
                    </li>

                    <?php if (isset($_SESSION["login"])) {
                        if ($_SESSION['login'] != "admin") { ?>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <?php echo ($_SESSION['login']); ?>
                        </a>
                    </li>
                    <?php } else { ?>
                    <li><a href="users.php">View Users</a></li>
                    <li><a href="editProducts.php">Edit Products</a></li>
                    <?php }
                    ?>
                    </li>
                    <li class="nav-item">
                        <form method="post" action="logout.php">
                            <input type="hidden" name="redirect" value="index.php">
                            <input class="login nav-link" type="submit" value="Logout" name="logout">
                        </form>
                    </li>
                    <?php } else { ?>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </nav>


    <style>
    /* Adjust image size */
    .Features img {
        max-width: 80%;
        height: auto;
        max-height: 140px;
        /* Adjust this value as needed */
    }
    </style>

    <section id="Books" class="container d-flex flex-column gap-5">
        <h1 class="mt-3 text-center display-4">Book Store</h1>
        <h2 class="text-center lead">Explore and download a variety of books for free.</h2>

        <div class="row row-cols-1 row-cols-md-3 justify-content-center gx-4">
            <div class="Features col d-flex flex-column rounded-lg bg-light">
                <a href="bookstore/Certified_Nutrition_coach.pdf" class="text-decoration-none text-dark" download>
                    <div class="d-flex justify-content-start align-items-center px-4 py-3 rounded-top bg-light">
                        <img src="imgs/cnm.png" alt="Book 1 Cover">
                        <h5 class="ms-3 mb-0">Certified Nutrition coach</h5>
                    </div>
                    <p class="px-4 text-muted">Download this comprehensive guide to nutrition plans and learn about
                        personalized meal plans and workouts with the personal coach.</p>
                </a>
            </div>

            <div class="Features col d-flex flex-column gap-4 rounded-lg bg-light">
                <a href="bookstore/The_Minicut_manual.pdf" class="text-decoration-none text-dark" download>
                    <div class="d-flex justify-content-start align-items-center px-4 py-3 rounded-top bg-light">
                        <img src="imgs/The_Minicut_Manual.png" alt="Book 2 Cover">
                        <h5 class="ms-3 mb-0">Certified Nutritionists Handbook</h5>
                    </div>
                    <p class="px-4 text-muted">Get a huge knowledge about minicut, in topics such as, Minicut Structure,
                        Diet Details on Minicuts, Training Details on Minicuts and Minicut Myths and Follies.
                    </p>
                </a>
            </div>

            <div class="Features col d-flex flex-column gap-4 rounded-lg  bg-light">
                <a href="bookstore/Recovering_from_Training.pdf" class="text-decoration-none text-dark" download>
                    <div class="d-flex justify-content-start align-items-center px-4 py-3 rounded-top bg-light">
                        <img src="imgs/Recovering_From_Training.png" alt="Book 3 Cover">
                        <h5 class="ms-3 mb-0">Recovering From Training</h5>
                    </div>
                    <p class="px-4 text-muted">Learn about topics like Fatigue, Recovery, Recovery Strategies, Passive
                        Recovery Strategies and Nutrition for Recovery .</p>
                </a>
            </div>

            <div class="Features col d-flex flex-column gap-4 rounded-lg  bg-light">
                <a href="bookstore/The_Muscles_and_strength.pdf" class="text-decoration-none text-dark" download>
                    <div class="d-flex justify-content-start align-items-center px-4 py-3 rounded-top bg-light">
                        <img src="imgs/The_Muscles_and_strength.png" alt="Book 4 Cover">
                        <h5 class="ms-3 mb-0">Lifestyle and Behavior Coaching Manual</h5>
                    </div>
                    <p class="px-4 text-muted">Download our manual on lifestyle and behavior coaching to learn about
                        developing healthy habits, addressing emotional eating, and overcoming obstacles.</p>
                </a>
            </div>

            <div class="Features col d-flex flex-column gap-4 rounded-lg  bg-light">
                <a href="bookstore/Scientific_Principles.pdf" class="text-decoration-none text-dark" download>
                    <div class="d-flex justify-content-start align-items-center px-4 py-3 rounded-top bg-light">
                        <img src="imgs/Scientific_Principles.png" alt="Book 4 Cover">
                        <h5 class="ms-3 mb-0">Scientific Principles</h5>
                    </div>
                    <p class="px-4 text-muted">Your best guide for gaining knowledge about Overload, fatigue Management,
                        SRA, Phase Potentiation and Individualization.</p>
                </a>
            </div>

            <div class="Features col d-flex flex-column gap-4 rounded-lg  bg-light">
                <a href="bookstore/paper.pdf" class="text-decoration-none text-dark" download>
                    <div class="d-flex justify-content-start align-items-center px-4 py-3 rounded-top bg-light">
                        <img src="imgs/paper.png" alt="Book 4 Cover">
                        <h5 class="ms-3 mb-0">recommendation for natural bodybuilding contest</h5>
                    </div>
                    <p class="px-4 text-muted">Download our manual on recommendation for natural bodybuilding contest.
                    </p>
                </a>
            </div>
        </div>
    </section>