<?php
session_start();
// Function to generate a CSRF token
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
// Function to validate the CSRF token
function validateCsrfToken($token) {
    return $token === $_SESSION['csrf_token'];
}
// Logout functionality
if (isset($_POST['logout'])) {
    if (validateCsrfToken($_POST['csrf_token'])) {
        session_destroy();
    } else {
        echo "Invalid CSRF token.";
        exit;
    }
}

// Redirect to login page if user is not logged in
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

require('conn.php');

// Retrieve user information from the database
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    $sql = "SELECT * FROM users WHERE id = $user_id";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
        } else {
            echo "User data not found.";
            exit;
        }
    } else {
        echo "Error executing query: " . mysqli_error($conn);
        exit;
    }
} else {
    echo "User ID not found in session.";
    exit;
}

// Update user's email and full name if form is submitted
if (isset($_POST['update'])) {
    if (validateCsrfToken($_POST['csrf_token'])) {
        $newEmail = htmlspecialchars($_POST['new_email']);
        $newFullName = htmlspecialchars($_POST['new_fullname']);

        // Update user's email and full name in the database
        $updateQuery = "UPDATE users SET uemail = '$newEmail', ufullname = '$newFullName' WHERE id = $user_id";
        $updateResult = mysqli_query($conn, $updateQuery);

        if ($updateResult) {
            // Reload the page to reflect changes
            header("Location: profile.php");
            exit;
        } else {
            echo "Error updating user information: " . mysqli_error($conn);
            exit;
        }
    } else {
        echo "Invalid CSRF token.";
        exit;
    }
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="Icon" href="imgs/logo2.png">

    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }

    .container1 {
        max-width: 600px;
        margin: 20px auto;
        background-color: #d1e5cd;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
        color: #333;
    }

    .profile-info {
        margin-bottom: 20px;
    }

    .profile-info p {
        margin: 10px 0;
    }

    .profile-photo {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        overflow: hidden;
        margin-bottom: 20px;
    }

    .profile-photo img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .upload-btn {
        padding: 10px 20px;
        background-color: #4caf50;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    .upload-btn:hover {
        background-color: #45a049;
    }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg ">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php"><img src="imgs/logo.png" alt=""></a>
            <button class="hamburger" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">

                <div class="line1"></div>
                <div class="line2"></div>
                <div class="line3"></div>

            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="nav ">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#Features">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">Blogs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="plans.php">Plans</a>
                    </li>

                    <?php if (isset($_SESSION["login"])) {
                        if ($_SESSION['login'] != "admin") { ?>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <?php echo ($_SESSION['login']); ?>
                        </a>
                    </li>
                    <?php } else { ?>
                    <li><a href="users.php">View Users</a></li>
                    <li><a href="editProducts.php">Edit Products</a></li>
                    <?php }
                        ?>
                    </li>
                    <li class="nav-item">
                        <form method="post" action="logout.php">
                            <input type="hidden" name="redirect" value="index.php">
                            <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                            <input class="login nav-link" type="submit" value="Logout" name="logout">
                        </form>
                    </li>
                    <?php } else { ?>
                    <li><a class="login nav-link" href="login.php">Login</a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container1">
        <h1>Welcome to Your Profile, <?php echo $user['ufullname']; ?></h1>
        <div class="profile-info">
            <div class="profile-photo" id="profile-photo">
                <!-- Display user photo if available -->
                <?php if (!empty($user['uimg'])) : ?>
                <img src="<?php echo $user['uimg']; ?>" alt="Profile Photo">
                <?php else : ?>
                <!-- Default profile photo -->
                <img src="imgs/profile.jpg" alt="Default Profile Photo">
                <?php endif; ?>
            </div>

            <input type="file" id="fileInput" style="display:none;" accept="image/*">
            <button class="upload-btn" id="uploadBtn">Upload Photo</button>
        </div>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
            <div class="form-group">
                <label for="new_email" style="margin-bottom: 10px">Update Email:</label>
                <input type="email" class="form-control" id="new_email" name="new_email"
                    style="margin-bottom: 10px;border-color: #0c0c0c;" value="<?php echo $user['uemail']; ?>">
            </div>
            <div class="form-group">
                <label for="new_fullname" style="margin-bottom: 10px; margin-top : 10px">Update Full Name:</label>
                <input type="text" class="form-control" id="new_fullname" name="new_fullname"
                    style="margin-bottom: 10px;border-color: #0c0c0c;" value="<?php echo $user['ufullname']; ?>">
            </div>
            <button type="submit" class="btn btn-primary" name="update">Update</button>
        </form>
    </div>

    <script>
    document.getElementById("uploadBtn").addEventListener("click", function() {
        document.getElementById("fileInput").click();
    });

    document.getElementById("fileInput").addEventListener("change", function() {
        var file = this.files[0];
        if (file) {
            var formData = new FormData();
            formData.append("file", file);

            var xhr = new XMLHttpRequest();
            xhr.open("POST", "upload_photo.php");
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        var response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            var imageUrl = response.imageUrl;
                            document.getElementById("profile-photo").innerHTML = '<img src="' + imageUrl +
                                '" alt="Profile Photo">';
                            console.log("Profile photo updated successfully.");
                        } else {
                            alert(response.message);
                        }
                    } else {
                        alert("Error uploading photo. Please try again later.");
                    }
                }
            };
            xhr.send(formData);
        }
    });
    </script>
</body>

</html>