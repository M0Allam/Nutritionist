    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="./css/style.css">
        <link rel="stylesheet" href="css\bootstrap.min.css">
        <link rel="Icon" href="imgs/logo2.png">
        <title>Gain Knowledge</title>

        <style>
        /* Add your CSS styles here */
        .d-none {
            display: none;
        }

        #downloadButton {
            display: none;
        }

        #downloadButtonDes {
            display: none;
        }

        /* Table Styling */
        .workout-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .workout-table th,
        .workout-table td {
            border: 1px solid #dddddd;
            text-align: center;
            padding: 8px;

        }

        .workout-table th {
            background-color: #f2f2f2;
        }

        /* Additional Styling */
        .workout-div {
            margin-top: 20px;
        }

        .workout-div li {
            margin-bottom: 10px;
        }

        .workout-div a {
            text-decoration: none;
            color: #007bff;
        }

        .workout-div a:hover {
            text-decoration: underline;
        }
        </style>
        <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script> -->
        <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.3/jspdf.umd.min.js"></script> -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.3/html2pdf.bundle.min.js"></script>

    </head>

    <body>
        <!-- navbar section  -->

        <nav class="navbar navbar-expand-lg ">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php"><img src="imgs\logo.png" alt=""></a>
                <button class="hamburger" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">

                    <div class="line1"></div>
                    <div class="line2"></div>
                    <div class="line3"></div>

                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="nav">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php#Features">Features</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="blog.php">Blogs</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="plans.php">Plans</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="books.php">Books</a>
                        </li>
                        <?php if (isset($_SESSION["login"])) { ?>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <?php echo $_SESSION['login']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <form method="post" action="logout.php">
                                <input type="hidden" name="redirect" value="index.php">
                                <input class="login nav-link" type="submit" value="Logout" name="logout">
                            </form>
                        </li>
                        <?php } else { ?>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- our blogs section -->


        <section id="Blogs" class="container d-flex flex-column justify-content-center align-items-start gap-5">
            <div class="row d-flex flex-column justify-content-center align-items-center gap-3">
                <div class="col text-center">
                    <h1 class="display-4">Gain Knowledge</h1>
                    <p class="lead">Our blog is a treasure trove of videos made by our
                        team of
                        nutritionists, dietitians, and wellness experts. Here's what you can expect from our blog.</p>
                </div>
            </div>
            <div class="row d-flex justify-content-center gap-4">
                <!-- Weight Loss Blog Card -->
                <a href="https://www.youtube.com/watch?v=x83BK2S9-5A" class="col-md-5 mb-3 text-decoration-none">
                    <div class="card rounded h-100">
                        <iframe width="100%" height="315" src="https://www.youtube.com/embed/x83BK2S9-5A"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen></iframe>
                        <div class="blogs card-body d-flex flex-column justify-content-between">
                            <div class="d-flex flex-column gap-2">
                                <h5 class="card-title">Muscle gaining</h5>
                                <p class="card-text">Discover how staying hydrated can support your weight loss goals
                                    and
                                    improve overall
                                    health.</p>
                            </div>

                        </div>
                    </div>
                </a>
                <!-- Mindful Eating Blog Card -->
                <a href="https://www.youtube.com/watch?v=iU5iWz4L06A" class="col-md-5 mb-3 text-decoration-none">
                    <div class="card shadow rounded h-100">
                        <iframe width="100%" height="315" src="https://www.youtube.com/embed/iU5iWz4L06A"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen></iframe>
                        <div class="blogs card-body d-flex flex-column justify-content-between">
                            <div class="d-flex flex-column gap-2">
                                <h5 class="card-title">Mindful Eating</h5>
                                <p class="card-text">Cultivating a Healthy Relationship with Food</p>
                            </div>

                        </div>
                    </div>
                </a>
                <!-- Understanding Macronutrients Blog Card -->
                <a href="https://www.youtube.com/watch?v=TMLTwv4dR1E&list=PLkVVAH-mp4DPJ2U7nhwkSTDUl1HOjJkqV"
                    class="col-md-5 mb-3 text-decoration-none">
                    <div class="card shadow rounded h-100">
                        <iframe width="100%" height="315" src="https://www.youtube.com/embed/TMLTwv4dR1E"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen></iframe>
                        <div class="blogs card-body d-flex flex-column justify-content-between">
                            <div class="d-flex flex-column gap-2">
                                <h5 class="card-title">Lat pull down</h5>
                                <p class="card-text">Back workout</p>
                            </div>

                        </div>
                    </div>
                </a>
                <!-- Healthy Snacks on the Go Blog Card -->
                <a href="https://www.youtube.com/watch?v=JrwrbNwEh58&list=PLkVVAH-mp4DMbGwspoi21B7tA8WS9h1kg"
                    class="col-md-5 mb-3 text-decoration-none">
                    <div class="card shadow rounded h-100">
                        <iframe width="100%" height="315" src="https://www.youtube.com/embed/JrwrbNwEh58"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen></iframe>
                        <div class="blogs card-body d-flex flex-column justify-content-between">
                            <div class="d-flex flex-column gap-2">
                                <h5 class="card-title">tri workout</h5>
                                <p class="card-text">Quick guide for tri workout</p>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="row d-flex justify-content-center gap-4">
                <!-- First YouTube shorts video -->
                <div class="col-md-5 mb-3 text-decoration-none">
                    <a href="https://www.youtube.com/shorts/k3GccMOzw6M">
                        <div class="card rounded h-100">
                            <iframe width="100%" height="315" src="https://www.youtube.com/embed/k3GccMOzw6M"
                                frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen></iframe>
                            <div class="blogs card-body d-flex flex-column justify-content-between">
                                <div class="d-flex flex-column gap-2">
                                    <h5 class="card-title">How to improve your body</h5>
                                    <p class="card-text">Follow these instructions</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <!-- Second YouTube shorts video -->
                <div class="col-md-5 mb-3 text-decoration-none">
                    <a href="https://www.youtube.com/shorts/0YpZMqOYw9A">
                        <div class="card shadow rounded h-100">
                            <iframe width="100%" height="315" src="https://www.youtube.com/embed/0YpZMqOYw9A"
                                frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen></iframe>
                            <div class="blogs card-body d-flex flex-column justify-content-between">
                                <div class="d-flex flex-column gap-2">
                                    <h5 class="card-title">Lateral shoulder</h5>
                                    <p class="card-text">Couldn't improve because of genes?</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <!-- Third YouTube shorts video -->
                <div class="col-md-5 mb-3 text-decoration-none">
                    <a href="https://www.youtube.com/shorts/zP5wyZKfVQQ">
                        <div class="card shadow rounded h-100">
                            <iframe width="100%" height="315" src="https://www.youtube.com/embed/zP5wyZKfVQQ"
                                frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen></iframe>
                            <div class="blogs card-body d-flex flex-column justify-content-between">
                                <div class="d-flex flex-column gap-2">
                                    <h5 class="card-title">high intensity low volume</h5>
                                    <p class="card-text">Is it require higher protien?</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <!-- Fourth YouTube shorts video -->
                <div class="col-md-5 mb-3 text-decoration-none">
                    <a href="https://www.youtube.com/shorts/CNJzph51sj0">
                        <div class="card shadow rounded h-100">
                            <iframe width="100%" height="315" src="https://www.youtube.com/embed/CNJzph51sj0"
                                frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen></iframe>
                            <div class="blogs card-body d-flex flex-column justify-content-between">
                                <div class="d-flex flex-column gap-2">
                                    <h5 class="card-title">Your daily calories</h5>
                                    <p class="card-text">Would it gain you fats?</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>

        </section>

        <footer class="footer py-3">
            <p class="copyright fw-bold display-8  text-white text-center">&copy; 2024 Nutritionist. All rights
                reserved.
            </p>
        </footer>


        <script src="js/main.js"></script>
        <script src="js\bootstrap.bundle.min.js"></script>